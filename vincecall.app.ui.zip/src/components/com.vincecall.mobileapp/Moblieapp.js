import React from 'react'

const Moblieapp = () => {
  return (
    <div>Moblieapp</div>
  )
}

export default Moblieapp