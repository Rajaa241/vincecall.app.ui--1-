import React from 'react'

const SMSConsolidateReports = () => {
  return (
    <div>SMSConsolidateReports</div>
  )
}

export default SMSConsolidateReports