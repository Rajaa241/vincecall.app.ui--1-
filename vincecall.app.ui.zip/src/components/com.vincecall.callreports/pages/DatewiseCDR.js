import React from 'react'

const DatewiseCDR = () => {
  return (
    <div>DatewiseCDR</div>
  )
}

export default DatewiseCDR