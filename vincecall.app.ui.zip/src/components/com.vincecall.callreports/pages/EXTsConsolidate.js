import React from 'react'

const EXTsConsolidate = () => {
  return (
    <div>EXTsConsolidate</div>
  )
}

export default EXTsConsolidate