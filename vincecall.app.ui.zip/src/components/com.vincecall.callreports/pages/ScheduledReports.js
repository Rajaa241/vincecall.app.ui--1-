import React from 'react'

const ScheduledReports = () => {
  return (
    <div>ScheduledReports</div>
  )
}

export default ScheduledReports