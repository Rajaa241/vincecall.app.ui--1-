import React from 'react'

const Timezone = () => {
  return (
    <div>Timezone</div>
  )
}

export default Timezone