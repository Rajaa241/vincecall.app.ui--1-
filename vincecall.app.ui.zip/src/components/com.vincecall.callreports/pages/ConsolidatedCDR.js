import React from 'react'

const ConsolidatedCDR = () => {
  return (
    <div>ConsolidatedCDR</div>
  )
}

export default ConsolidatedCDR