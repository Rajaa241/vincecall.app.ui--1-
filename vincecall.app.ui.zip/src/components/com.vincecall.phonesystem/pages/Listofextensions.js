import React, { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom';
import { axiosInstance } from '../../../interceptors/AxiosInterceptor'
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Paper from '@mui/material/Paper';
import { Card, CardHeader, Chip, Divider, Menu, MenuItem, Typography } from '@mui/material';



const Listofextensions = (props) => {
  const [extensions, setExtensions] = useState({});
  const [anchorEl, setAnchorEl] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    props.setLoading(true)
    axiosInstance.get("/admin/fetch-extensions")
      .then(res => {
        setExtensions(res.data.data)
        props.setLoading(false)
      }).catch(err => { console.log(err) })

    axiosInstance.get("/admin/hello")
      .then(res => { console.log(res.data.data) }).catch(err => { console.log(err) })


  }, [])
  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    setAnchorEl(null);
  };
  return (
    <Card sx={{ borderTop: 'inset', margin: '80px' }}>
      <CardHeader title="List Of Extensions"></CardHeader>
      <Divider />
      {Object.keys(extensions).length === 0 ? <Typography sx={{ display: 'flex', justifyContent: 'center' }}>Select dates to display the cdrs</Typography> :
        <TableContainer sx={{ margin: '20px', width: "94%" }} component={Paper}>
          <Table stickyHeader aria-label="simple table">
            <TableHead sx={{ backgroundColor: "gray" }}>
              <TableRow>
                <TableCell sx={{ backgroundColor: '#17479e', color: 'white' }}>S.no</TableCell>
                <TableCell sx={{ backgroundColor: '#17479e', color: 'white' }}>Caller Id</TableCell>
                <TableCell sx={{ backgroundColor: '#17479e', color: 'white' }}>Ext/Destination</TableCell>
                <TableCell sx={{ backgroundColor: '#17479e', color: 'white' }}>Display Name</TableCell>
                <TableCell sx={{ backgroundColor: '#17479e', color: 'white' }}>Action</TableCell>
              </TableRow>
            </TableHead>
            {
              extensions.fetchAllExtensions?.extension.map((header, index) =>
                <>
                  <TableBody>
                    <TableRow
                      sx={{ '&:last-child td, &:last-child th': { border: 0 } }}
                    >
                      <TableCell>{index + 1}</TableCell>
                      <TableCell>{header.user.outboundCid}</TableCell>
                      <TableCell>{header.coreDevice.deviceId}</TableCell>
                      <TableCell>{header.user.name}</TableCell>
                      <TableCell>
                        <Chip label="Inbound Calling Report" sx={{ cursor: 'pointer' }}
                          onClick={() => {
                            let str = header.extensionId;
                            navigate("/phonesystem/DirectNumberList/inboundcallingreports",
                              { state: { extension: `${str} - Inbound Call Records`, id: str, title: "extensions" } })
                          }} />
                        {/* <Chip label="Action" sx={{ backgroundColor: '#17479e', color: 'white', cursor: 'pointer' }} onClick={handleClick} /> */}
                        {/* <Menu
                          id="basic-menu"
                          anchorEl={anchorEl}
                          open={Boolean(anchorEl)}
                          onClose={handleClose}
                          MenuListProps={{
                            'aria-labelledby': 'basic-button',
                          }}
                        >
                          <MenuItem onClick={handleClose}>
                            CNAM update
                          </MenuItem>
                          <MenuItem onClick={() => {
                            console.log(header.extensionId);
                            // navigate("/phonesystem/DirectNumberList/inboundcallingreports", {
                            //   state: {
                            //     extension: `${header?.coreDevice?.deviceId} - Call Records`,
                            //     title: "extensions",
                            //     id: header?.extensionId
                            //   }
                            // })
                          }}>
                            Inbound Call Reports
                          </MenuItem>
                        </Menu> */}
                      </TableCell>
                    </TableRow>
                  </TableBody>
                </>
              )
            }

          </Table>

        </TableContainer>}
      {/* <Grid sx={{ display: 'flex', justifyContent: 'center' }}>
        <Pagination />
      </Grid> */}
    </Card>
  )
}

export default Listofextensions