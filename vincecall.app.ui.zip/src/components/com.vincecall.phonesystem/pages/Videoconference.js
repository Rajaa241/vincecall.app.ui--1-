import React from 'react'

const Videoconference = () => {
  return (
    <div>Videoconference</div>
  )
}

export default Videoconference