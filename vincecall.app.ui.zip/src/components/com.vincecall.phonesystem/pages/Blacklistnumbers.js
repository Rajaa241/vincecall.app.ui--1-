import React from 'react'

const Blacklistnumbers = () => {
  return (
    <div>Blacklistnumbers</div>
  )
}

export default Blacklistnumbers