import React from 'react'

const Pbxsetting = () => {
  return (
    <div>Pbxsetting</div>
  )
}

export default Pbxsetting