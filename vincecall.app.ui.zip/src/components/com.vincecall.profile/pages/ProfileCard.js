import React from 'react'

const ProfileCard = () => {



  return (
    <>
      profile
    </>
  )
}

export default ProfileCard