import React from 'react'

const BillingSummary = () => {
  return (
    <div>BillingSummary</div>
  )
}

export default BillingSummary