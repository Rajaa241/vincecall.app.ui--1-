import React from 'react'

const Billinginformation = () => {
  return (
    <div>Billinginformation</div>
  )
}

export default Billinginformation