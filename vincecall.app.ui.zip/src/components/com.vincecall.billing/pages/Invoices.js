import React from 'react'

const Invoices = () => {
  return (
    <div>Invoices</div>
  )
}

export default Invoices