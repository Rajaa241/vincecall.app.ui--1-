export const USER_EMAIL_FIELD_ID = "username";
export const USER_PASSWORD_FIELD_ID = "password";
export const USER_GQLURI_FIELD_ID = "gqluri";
export const USER_REGISTRATION_FIELD_ID = "registrationId";
export const USER_ROLE_FIELD_ID = "role";


export const ADDRESS_FIELD_ID = "address"
export const SERVICE_FIELD_ID = "service"
export const SERVICE_RATE_FIELD_ID = "rate"
export const SERVICE_STATUS_FIELD_ID = "serviceStatus"
export const CITY_FIELD_ID = "city"
export const ZIP_FIELD_ID = "zipcode"
export const STATE_FIELD_ID = "state"
export const COUNTRY_FIELD_ID = "country"
export const COMPANY_FIELD_ID = "company"
export const USERNAME_FIELD_ID = "username"
export const FEDERAL_FIELD_ID = "federalId"
export const CEO_FIELD_ID = "ceoName"
export const DRIVERLISENCE_FIELD_ID = "driverLisence"
export const ADDRESSPROOF_FIELD_ID = "addressProof"

